// utils.js — общие серверные валидаторы (используются в routes/auth.js)

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^[\d+][\d\s()+-]{5,19}$/;

module.exports = { EMAIL_RE, PHONE_RE };
