// public/js/pages/teacher-students.js

(async function () {
  const user = await bootPage('teacher');
  if (!user) return;

  const content = document.getElementById('content');

  try {
    const { students } = await api.get('/api/teacher/students');
    render(students);
  } catch (err) {
    content.innerHTML = `<ul class="error-list"><li>${escapeHtml(err.message)}</li></ul>`;
  }

  function render(students) {
    if (!students.length) {
      content.innerHTML = `
        <div class="empty-state">
          <div class="empty-state__icon">👥</div>
          <div class="empty-state__title">Учеников пока нет</div>
          <p class="empty-state__text">Как только кто-то зарегистрируется как ученик, он появится в этом списке.</p>
        </div>`;
      return;
    }

    content.innerHTML = `
      <div class="panel">
        <span class="panel__tab">Список учеников</span>
        <div class="table-scroll">
          <table class="table">
            <thead><tr><th>Имя</th><th>Фамилия</th><th>Город</th><th>Телефон</th><th>Почта</th><th>Дата регистрации</th></tr></thead>
            <tbody>${students.map((s) => `
              <tr>
                <td class="cell-title">${escapeHtml(s.firstName)}</td>
                <td>${escapeHtml(s.lastName)}</td>
                <td>${escapeHtml(s.city)}</td>
                <td class="cell-year">${escapeHtml(s.phone)}</td>
                <td>${escapeHtml(s.email)}</td>
                <td>${formatDate(s.createdAt)}</td>
              </tr>`).join('')}</tbody>
          </table>
        </div>
        <p class="panel__count">Всего: ${students.length}</p>
      </div>`;
  }
})();
