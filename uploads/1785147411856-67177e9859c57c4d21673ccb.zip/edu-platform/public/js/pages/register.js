// public/js/pages/register.js

(async function redirectIfLoggedIn() {
  try {
    const { user } = await api.get('/api/me');
    window.location.href = user.role === 'teacher' ? '/teacher/courses.html' : '/student/courses.html';
  } catch (e) { /* не авторизован — остаёмся */ }
})();

const form = document.getElementById('register-form');
const errorsBox = document.getElementById('form-errors');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  renderErrors(errorsBox, null);

  const payload = {
    role: form.role.value,
    firstName: form.firstName.value,
    lastName: form.lastName.value,
    city: form.city.value,
    phone: form.phone.value,
    email: form.email.value,
    password: form.password.value,
    passwordConfirm: form.passwordConfirm.value,
  };

  if (payload.password !== payload.passwordConfirm) {
    renderErrors(errorsBox, ['Пароли не совпадают.']);
    return;
  }

  try {
    const { user } = await api.postJson('/api/register', payload);
    window.location.href = user.role === 'teacher' ? '/teacher/courses.html' : '/student/courses.html';
  } catch (err) {
    renderErrors(errorsBox, err.errors || [err.message]);
  }
});
