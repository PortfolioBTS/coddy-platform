// public/js/pages/profile.js

(async function () {
  const requiredRole = window.location.pathname.startsWith('/teacher/') ? 'teacher' : 'student';
  const user = await bootPage(requiredRole);
  if (!user) return;

  document.getElementById('role-badge').textContent = user.role === 'teacher' ? 'Учитель' : 'Ученик';

  const fields = [
    ['Имя', user.firstName],
    ['Фамилия', user.lastName],
    ['Город', user.city],
    ['Телефон', user.phone],
    ['Электронная почта', user.email],
    ['В журнале с', formatDate(user.createdAt)],
  ];

  document.getElementById('content').innerHTML = fields.map(([label, value]) => `
    <div class="profile-field">
      <p class="profile-field__label">${escapeHtml(label)}</p>
      <p class="profile-field__value">${escapeHtml(value)}</p>
    </div>`).join('');
})();
